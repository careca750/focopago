import React, { useState } from 'react';
import { X, Target, Calendar, DollarSign } from 'lucide-react';
import { supabase } from '../lib/supabase';

interface NewGoalModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSuccess: () => void;
  userCoins: number;
}

export function NewGoalModal({ isOpen, onClose, onSuccess, userCoins }: NewGoalModalProps) {
  const [formData, setFormData] = useState({
    title: '',
    description: '',
    deadline: '',
    reward: 0
  });

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    if (formData.reward > userCoins) {
      alert('Você não tem coins suficientes para esta recompensa');
      return;
    }

    try {
      const { error } = await supabase.from('goals').insert([{
        title: formData.title,
        description: formData.description,
        deadline: formData.deadline,
        reward: formData.reward,
        user_id: (await supabase.auth.getUser()).data.user?.id
      }]);

      if (error) throw error;

      // Atualizar os coins do usuário
      await supabase
        .from('profiles')
        .update({ coins: userCoins - formData.reward })
        .eq('id', (await supabase.auth.getUser()).data.user?.id);

      onSuccess();
      onClose();
    } catch (error) {
      console.error('Erro ao criar meta:', error);
      alert('Erro ao criar meta. Tente novamente.');
    }
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50">
      <div className="bg-[#1E1E1E] rounded-2xl p-8 w-full max-w-md relative border border-white/10">
        <button 
          onClick={onClose}
          className="absolute right-4 top-4 text-white/60 hover:text-white"
        >
          <X className="w-6 h-6" />
        </button>

        <h2 className="text-2xl font-bold mb-6">Nova Meta</h2>

        <form onSubmit={handleSubmit} className="space-y-6">
          <div>
            <label className="block text-sm font-medium mb-2">Título</label>
            <div className="relative">
              <Target className="absolute left-4 top-3 w-5 h-5 text-white/40" />
              <input
                type="text"
                value={formData.title}
                onChange={(e) => setFormData(prev => ({ ...prev, title: e.target.value }))}
                className="w-full bg-white/5 border border-white/10 rounded-xl py-3 px-12 focus:outline-none focus:border-[#00D084]"
                placeholder="Digite o título da sua meta"
                required
              />
            </div>
          </div>

          <div>
            <label className="block text-sm font-medium mb-2">Descrição</label>
            <textarea
              value={formData.description}
              onChange={(e) => setFormData(prev => ({ ...prev, description: e.target.value }))}
              className="w-full bg-white/5 border border-white/10 rounded-xl py-3 px-4 focus:outline-none focus:border-[#00D084] min-h-[100px]"
              placeholder="Descreva sua meta em detalhes"
            />
          </div>

          <div>
            <label className="block text-sm font-medium mb-2">Prazo</label>
            <div className="relative">
              <Calendar className="absolute left-4 top-3 w-5 h-5 text-white/40" />
              <input
                type="date"
                value={formData.deadline}
                onChange={(e) => setFormData(prev => ({ ...prev, deadline: e.target.value }))}
                className="w-full bg-white/5 border border-white/10 rounded-xl py-3 px-12 focus:outline-none focus:border-[#00D084]"
              />
            </div>
          </div>

          <div>
            <label className="block text-sm font-medium mb-2">Recompensa (coins)</label>
            <div className="relative">
              <DollarSign className="absolute left-4 top-3 w-5 h-5 text-white/40" />
              <input
                type="number"
                value={formData.reward}
                onChange={(e) => setFormData(prev => ({ ...prev, reward: Number(e.target.value) }))}
                className="w-full bg-white/5 border border-white/10 rounded-xl py-3 px-12 focus:outline-none focus:border-[#00D084]"
                placeholder="100"
                required
                min="0"
                max={userCoins}
              />
            </div>
            <p className="text-sm text-white/60 mt-2">Coins disponíveis: {userCoins}</p>
          </div>

          <button
            type="submit"
            className="w-full bg-[#00D084] text-black px-6 py-4 rounded-full font-bold hover:bg-[#00D084]/90 transition-all"
          >
            Criar Meta
          </button>
        </form>
      </div>
    </div>
  );
}