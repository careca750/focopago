import React, { useState, useEffect } from 'react';
import { DashboardNavigation } from '../components/DashboardNavigation';
import { Wallet, CreditCard, QrCode, Plus } from 'lucide-react';
import { supabase } from '../lib/supabase';
import type { Profile } from '../types/database';

export function Carteira() {
  const [profile, setProfile] = useState<Profile | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    fetchProfile();
  }, []);

  const fetchProfile = async () => {
    try {
      const { data: { user } } = await supabase.auth.getUser();
      if (!user) throw new Error('Usuário não encontrado');

      const { data: profile, error } = await supabase
        .from('profiles')
        .select('*')
        .eq('id', user.id)
        .single();

      if (error) throw error;
      setProfile(profile);
    } catch (error) {
      console.error('Erro ao carregar perfil:', error);
    } finally {
      setLoading(false);
    }
  };

  const addCoins = async (amount: number) => {
    try {
      const { data: { user } } = await supabase.auth.getUser();
      if (!user) throw new Error('Usuário não encontrado');

      const { error } = await supabase
        .from('profiles')
        .update({ coins: (profile?.coins || 0) + amount })
        .eq('id', user.id);

      if (error) throw error;
      fetchProfile();
    } catch (error) {
      console.error('Erro ao adicionar coins:', error);
      alert('Erro ao adicionar coins. Tente novamente.');
    }
  };

  return (
    <div className="min-h-screen bg-[#1E1E1E]">
      <DashboardNavigation />
      
      <div className="container mx-auto px-4 pt-24">
        <div className="max-w-4xl mx-auto">
          <div className="bg-white/5 rounded-2xl p-8 mb-8">
            <div className="flex items-center justify-between mb-6">
              <h2 className="text-2xl font-bold">Sua Carteira</h2>
              <div className="bg-[#00D084]/10 p-3 rounded-full">
                <Wallet className="w-6 h-6 text-[#00D084]" />
              </div>
            </div>
            
            <div className="text-4xl font-bold text-[#00D084] mb-4">
              {profile?.coins || 0} <span className="text-xl">coins</span>
            </div>
          </div>

          <h3 className="text-xl font-bold mb-6">Adicionar Coins</h3>
          
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            <button
              onClick={() => addCoins(100)}
              className="bg-white/5 rounded-xl p-6 hover:bg-white/10 transition-all text-left"
            >
              <div className="flex items-center justify-between mb-4">
                <span className="text-2xl font-bold">100 coins</span>
                <Plus className="w-5 h-5 text-[#00D084]" />
              </div>
              <p className="text-white/60">R$ 10,00</p>
            </button>

            <button
              onClick={() => addCoins(500)}
              className="bg-white/5 rounded-xl p-6 hover:bg-white/10 transition-all text-left"
            >
              <div className="flex items-center justify-between mb-4">
                <span className="text-2xl font-bold">500 coins</span>
                <Plus className="w-5 h-5 text-[#00D084]" />
              </div>
              <p className="text-white/60">R$ 45,00</p>
            </button>

            <button
              onClick={() => addCoins(1000)}
              className="bg-white/5 rounded-xl p-6 hover:bg-white/10 transition-all text-left"
            >
              <div className="flex items-center justify-between mb-4">
                <span className="text-2xl font-bold">1000 coins</span>
                <Plus className="w-5 h-5 text-[#00D084]" />
              </div>
              <p className="text-white/60">R$ 80,00</p>
            </button>
          </div>

          <div className="mt-12">
            <h3 className="text-xl font-bold mb-6">Métodos de Pagamento</h3>
            
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <button className="bg-white/5 rounded-xl p-6 hover:bg-white/10 transition-all flex items-center">
                <CreditCard className="w-6 h-6 text-[#00D084] mr-4" />
                <div>
                  <h4 className="font-bold mb-1">Cartão de Crédito</h4>
                  <p className="text-white/60 text-sm">Visa, Mastercard, Elo</p>
                </div>
              </button>

              <button className="bg-white/5 rounded-xl p-6 hover:bg-white/10 transition-all flex items-center">
                <QrCode className="w-6 h-6 text-[#00D084] mr-4" />
                <div>
                  <h4 className="font-bold mb-1">Pix</h4>
                  <p className="text-white/60 text-sm">Pagamento instantâneo</p>
                </div>
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}