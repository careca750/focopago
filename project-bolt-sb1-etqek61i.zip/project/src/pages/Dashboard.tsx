import React, { useState, useEffect } from 'react';
import { 
  Plus, 
  Target, 
  Trophy, 
  Clock, 
  ArrowRight,
  Users,
  TrendingUp,
  Calendar,
  Award
} from 'lucide-react';
import { DashboardNavigation } from '../components/DashboardNavigation';
import { NewGoalModal } from '../components/NewGoalModal';
import { supabase } from '../lib/supabase';
import type { Goal, Profile } from '../types/database';
import { useNavigate } from 'react-router-dom';

export function Dashboard() {
  const navigate = useNavigate();
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [metas, setMetas] = useState<Goal[]>([]);
  const [profile, setProfile] = useState<Profile | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    fetchData();
  }, []);

  const fetchData = async () => {
    try {
      const { data: { user } } = await supabase.auth.getUser();
      if (!user) throw new Error('Usuário não encontrado');

      // Carregar perfil
      const { data: profileData, error: profileError } = await supabase
        .from('profiles')
        .select('*')
        .eq('id', user.id)
        .single();

      if (profileError) throw profileError;
      setProfile(profileData);

      // Carregar metas
      const { data: goalsData, error: goalsError } = await supabase
        .from('goals')
        .select('*')
        .eq('user_id', user.id)
        .order('created_at', { ascending: false });

      if (goalsError) throw goalsError;
      setMetas(goalsData);
    } catch (error) {
      console.error('Erro ao carregar dados:', error);
    } finally {
      setLoading(false);
    }
  };

  const concluirMeta = async (id: string) => {
    try {
      const meta = metas.find(m => m.id === id);
      if (!meta) return;

      const { error: updateError } = await supabase
        .from('goals')
        .update({ status: 'completed' })
        .eq('id', id);

      if (updateError) throw updateError;

      // Atualizar coins do usuário
      const { error: profileError } = await supabase
        .from('profiles')
        .update({ coins: (profile?.coins || 0) + meta.reward })
        .eq('id', profile?.id);

      if (profileError) throw profileError;

      fetchData();
    } catch (error) {
      console.error('Erro ao concluir meta:', error);
      alert('Erro ao concluir meta. Tente novamente.');
    }
  };

  const handleNewGoal = () => {
    if (!profile?.coins || profile.coins === 0) {
      if (confirm('Você não tem coins suficientes. Deseja adicionar coins à sua carteira?')) {
        navigate('/carteira');
      }
      return;
    }
    setIsModalOpen(true);
  };

  if (loading) {
    return (
      <div className="flex h-screen items-center justify-center bg-[#1E1E1E]">
        <div className="animate-spin rounded-full h-8 w-8 border-t-2 border-[#00D084]"></div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-[#1E1E1E]">
      <DashboardNavigation />
      
      <div className="ml-64 p-8 pt-24">
        {/* Welcome Section */}
        <div className="mb-8">
          <h1 className="text-3xl font-bold mb-2">Olá, {profile?.name || 'Usuário'}</h1>
          <p className="text-white/60">Bem-vindo(a) de volta ao seu dashboard</p>
        </div>

        {/* Stats Grid */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-6 mb-8">
          <div className="bg-white/5 rounded-2xl p-6">
            <div className="flex items-center justify-between mb-4">
              <h3 className="text-lg font-bold">Saldo</h3>
              <div className="bg-[#00D084]/10 p-2 rounded-full">
                <Trophy className="w-6 h-6 text-[#00D084]" />
              </div>
            </div>
            <p className="text-3xl font-bold text-[#00D084]">{profile?.coins || 0} coins</p>
            <p className="text-sm text-white/60 mt-2">+15% este mês</p>
          </div>

          <div className="bg-white/5 rounded-2xl p-6">
            <div className="flex items-center justify-between mb-4">
              <h3 className="text-lg font-bold">Metas Ativas</h3>
              <div className="bg-[#00D084]/10 p-2 rounded-full">
                <Target className="w-6 h-6 text-[#00D084]" />
              </div>
            </div>
            <p className="text-3xl font-bold">{metas.filter(m => m.status === 'pending').length}</p>
            <p className="text-sm text-white/60 mt-2">2 próximas do prazo</p>
          </div>

          <div className="bg-white/5 rounded-2xl p-6">
            <div className="flex items-center justify-between mb-4">
              <h3 className="text-lg font-bold">Concluídas</h3>
              <div className="bg-[#00D084]/10 p-2 rounded-full">
                <Clock className="w-6 h-6 text-[#00D084]" />
              </div>
            </div>
            <p className="text-3xl font-bold">{metas.filter(m => m.status === 'completed').length}</p>
            <p className="text-sm text-white/60 mt-2">85% de conclusão</p>
          </div>

          <div className="bg-white/5 rounded-2xl p-6">
            <div className="flex items-center justify-between mb-4">
              <h3 className="text-lg font-bold">Equipe</h3>
              <div className="bg-[#00D084]/10 p-2 rounded-full">
                <Users className="w-6 h-6 text-[#00D084]" />
              </div>
            </div>
            <p className="text-3xl font-bold">12</p>
            <p className="text-sm text-white/60 mt-2">3 online agora</p>
          </div>
        </div>

        {/* Quick Actions */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-6 mb-12">
          <button 
            onClick={handleNewGoal}
            className="bg-[#00D084] text-black p-6 rounded-2xl hover:bg-[#00D084]/90 transition-all text-left"
          >
            <Plus className="w-6 h-6 mb-4" />
            <h3 className="font-bold mb-1">Nova Meta</h3>
            <p className="text-sm opacity-80">Criar nova meta ou desafio</p>
          </button>

          <button className="bg-white/5 p-6 rounded-2xl hover:bg-white/10 transition-all text-left">
            <TrendingUp className="w-6 h-6 text-[#00D084] mb-4" />
            <h3 className="font-bold mb-1">Analytics</h3>
            <p className="text-sm text-white/60">Ver relatórios detalhados</p>
          </button>

          <button className="bg-white/5 p-6 rounded-2xl hover:bg-white/10 transition-all text-left">
            <Calendar className="w-6 h-6 text-[#00D084] mb-4" />
            <h3 className="font-bold mb-1">Calendário</h3>
            <p className="text-sm text-white/60">Visualizar prazos</p>
          </button>

          <button className="bg-white/5 p-6 rounded-2xl hover:bg-white/10 transition-all text-left">
            <Award className="w-6 h-6 text-[#00D084] mb-4" />
            <h3 className="font-bold mb-1">Conquistas</h3>
            <p className="text-sm text-white/60">Ver suas conquistas</p>
          </button>
        </div>

        {/* Goals Section */}
        <div className="bg-white/5 rounded-2xl p-8">
          <div className="flex justify-between items-center mb-8">
            <h2 className="text-2xl font-bold">Suas Metas</h2>
            <button 
              onClick={handleNewGoal}
              className="bg-[#00D084] text-black px-4 py-2 rounded-full font-bold hover:bg-[#00D084]/90 transition-all flex items-center"
            >
              <Plus className="w-5 h-5 mr-2" />
              Nova Meta
            </button>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            {metas.map(meta => (
              <div key={meta.id} className="bg-white/5 rounded-xl p-6">
                <div className="flex justify-between items-start mb-4">
                  <div>
                    <h3 className="text-xl font-bold mb-2">{meta.title}</h3>
                    <p className="text-white/60 mb-4">{meta.description}</p>
                  </div>
                  <span className={`px-3 py-1 rounded-full text-sm font-bold ${
                    meta.status === 'completed' 
                      ? 'bg-[#00D084]/10 text-[#00D084]' 
                      : 'bg-white/10 text-white'
                  }`}>
                    {meta.status === 'completed' ? 'Concluída' : 'Pendente'}
                  </span>
                </div>
                
                <div className="flex justify-between items-center">
                  <div>
                    <p className="text-sm text-white/60">Prazo</p>
                    <p className="font-bold">
                      {meta.deadline ? new Date(meta.deadline).toLocaleDateString() : 'Sem prazo'}
                    </p>
                  </div>
                  <div>
                    <p className="text-sm text-white/60">Recompensa</p>
                    <p className="font-bold text-[#00D084]">{meta.reward} coins</p>
                  </div>
                  {meta.status === 'pending' && (
                    <button 
                      onClick={() => concluirMeta(meta.id)}
                      className="bg-[#00D084] text-black px-4 py-2 rounded-full font-bold hover:bg-[#00D084]/90 transition-all flex items-center"
                    >
                      Concluir
                      <ArrowRight className="w-4 h-4 ml-2" />
                    </button>
                  )}
                </div>
              </div>
            ))}
          </div>
        </div>

        <NewGoalModal 
          isOpen={isModalOpen}
          onClose={() => setIsModalOpen(false)}
          onSuccess={fetchData}
          userCoins={profile?.coins || 0}
        />
      </div>
    </div>
  );
}