import React from 'react';
import { Routes, Route, useLocation } from 'react-router-dom';
import { Navigation } from './components/Navigation';
import { Home } from './pages/Home';
import { Plans } from './pages/Plans';
import { About } from './pages/About';
import { Help } from './pages/Help';
import { Blog } from './pages/Blog';
import { Dashboard } from './pages/Dashboard';
import { Carteira } from './pages/Carteira';
import { Footer } from './components/Footer';
import { Login } from './pages/Login';
import { Cadastro } from './pages/Cadastro';
import { Empresas } from './pages/Empresas';

function App() {
  const location = useLocation();
  const isDashboardRoute = ['/dashboard', '/carteira', '/metas'].includes(location.pathname);

  return (
    <div className="min-h-screen bg-[#1E1E1E] text-white font-['Poppins']">
      {!isDashboardRoute && <Navigation />}
      <Routes>
        <Route path="/" element={<Home />} />
        <Route path="/planos" element={<Plans />} />
        <Route path="/sobre" element={<About />} />
        <Route path="/ajuda" element={<Help />} />
        <Route path="/blog" element={<Blog />} />
        <Route path="/dashboard" element={<Dashboard />} />
        <Route path="/carteira" element={<Carteira />} />
        <Route path="/login" element={<Login />} />
        <Route path="/cadastro" element={<Cadastro />} />
        <Route path="/empresas" element={<Empresas />} />
      </Routes>
      {!isDashboardRoute && <Footer />}
    </div>
  );
}

export default App;