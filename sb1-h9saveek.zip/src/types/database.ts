export type Profile = {
  id: string;
  name: string | null;
  coins: number;
  created_at: string;
  updated_at: string;
};

export type Goal = {
  id: string;
  user_id: string;
  title: string;
  description: string | null;
  deadline: string | null;
  reward: number;
  status: 'pending' | 'completed';
  created_at: string;
  updated_at: string;
};