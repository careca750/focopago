import React, { useState } from 'react';
import { Link, useLocation } from 'react-router-dom';
import { 
  Layout, 
  Target, 
  Wallet, 
  Users, 
  Settings, 
  BarChart2, 
  Award,
  Bell,
  LogOut 
} from 'lucide-react';
import { supabase } from '../lib/supabase';

export function DashboardNavigation() {
  const location = useLocation();
  const [notifications, setNotifications] = useState(3); // Example notification count
  
  const handleLogout = async () => {
    await supabase.auth.signOut();
    window.location.href = '/';
  };

  const isActive = (path: string) => location.pathname === path;
  
  return (
    <div className="flex h-screen">
      {/* Sidebar */}
      <div className="w-64 bg-[#1A1A1A] border-r border-white/10 fixed h-full">
        <div className="p-6">
          <Link to="/dashboard" className="text-2xl font-bold text-[#00D084]">FocoPago</Link>
        </div>
        
        <nav className="mt-6">
          <div className="px-4 mb-4">
            <p className="text-xs font-medium text-white/40 uppercase tracking-wider">Principal</p>
          </div>
          <Link 
            to="/dashboard" 
            className={`flex items-center px-6 py-3 text-sm ${
              isActive('/dashboard') 
                ? 'text-[#00D084] bg-[#00D084]/10' 
                : 'text-white/60 hover:text-white hover:bg-white/5'
            }`}
          >
            <Layout className="w-5 h-5 mr-3" />
            <span>Dashboard</span>
          </Link>
          
          <Link 
            to="/metas" 
            className={`flex items-center px-6 py-3 text-sm ${
              isActive('/metas') 
                ? 'text-[#00D084] bg-[#00D084]/10' 
                : 'text-white/60 hover:text-white hover:bg-white/5'
            }`}
          >
            <Target className="w-5 h-5 mr-3" />
            <span>Metas</span>
          </Link>
          
          <Link 
            to="/carteira" 
            className={`flex items-center px-6 py-3 text-sm ${
              isActive('/carteira') 
                ? 'text-[#00D084] bg-[#00D084]/10' 
                : 'text-white/60 hover:text-white hover:bg-white/5'
            }`}
          >
            <Wallet className="w-5 h-5 mr-3" />
            <span>Carteira</span>
          </Link>

          <div className="px-4 mt-8 mb-4">
            <p className="text-xs font-medium text-white/40 uppercase tracking-wider">Empresa</p>
          </div>
          
          <Link 
            to="/equipe" 
            className={`flex items-center px-6 py-3 text-sm ${
              isActive('/equipe') 
                ? 'text-[#00D084] bg-[#00D084]/10' 
                : 'text-white/60 hover:text-white hover:bg-white/5'
            }`}
          >
            <Users className="w-5 h-5 mr-3" />
            <span>Equipe</span>
          </Link>
          
          <Link 
            to="/analytics" 
            className={`flex items-center px-6 py-3 text-sm ${
              isActive('/analytics') 
                ? 'text-[#00D084] bg-[#00D084]/10' 
                : 'text-white/60 hover:text-white hover:bg-white/5'
            }`}
          >
            <BarChart2 className="w-5 h-5 mr-3" />
            <span>Analytics</span>
          </Link>
          
          <Link 
            to="/conquistas" 
            className={`flex items-center px-6 py-3 text-sm ${
              isActive('/conquistas') 
                ? 'text-[#00D084] bg-[#00D084]/10' 
                : 'text-white/60 hover:text-white hover:bg-white/5'
            }`}
          >
            <Award className="w-5 h-5 mr-3" />
            <span>Conquistas</span>
          </Link>

          <div className="px-4 mt-8 mb-4">
            <p className="text-xs font-medium text-white/40 uppercase tracking-wider">Configurações</p>
          </div>
          
          <Link 
            to="/configuracoes" 
            className={`flex items-center px-6 py-3 text-sm ${
              isActive('/configuracoes') 
                ? 'text-[#00D084] bg-[#00D084]/10' 
                : 'text-white/60 hover:text-white hover:bg-white/5'
            }`}
          >
            <Settings className="w-5 h-5 mr-3" />
            <span>Configurações</span>
          </Link>
        </nav>
      </div>

      {/* Top Navigation */}
      <div className="flex-1 ml-64">
        <div className="bg-[#1A1A1A] border-b border-white/10 h-16 flex items-center justify-end px-6 fixed w-[calc(100%-16rem)] z-10">
          <div className="flex items-center space-x-4">
            <button className="relative p-2 text-white/60 hover:text-white">
              <Bell className="w-5 h-5" />
              {notifications > 0 && (
                <span className="absolute top-0 right-0 bg-[#00D084] text-black text-xs w-4 h-4 rounded-full flex items-center justify-center">
                  {notifications}
                </span>
              )}
            </button>
            
            <button 
              onClick={handleLogout}
              className="flex items-center space-x-2 text-white/60 hover:text-white"
            >
              <LogOut className="w-5 h-5" />
              <span>Sair</span>
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}